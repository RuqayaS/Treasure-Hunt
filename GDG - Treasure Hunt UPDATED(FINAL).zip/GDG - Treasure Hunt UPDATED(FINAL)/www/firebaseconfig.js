// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.2.0/firebase-app.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBHVY_IcsV36-U2bA_rV-sPhzMP-CNwH_8",
  authDomain: "cyber-challenge-b305c.firebaseapp.com",
  projectId: "cyber-challenge-b305c",
  storageBucket: "cyber-challenge-b305c.firebasestorage.app",
  messagingSenderId: "531812621738",
  appId: "1:531812621738:web:d2fbd459cc4744dea5dfd3",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
